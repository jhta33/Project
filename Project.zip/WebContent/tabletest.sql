select * from TESTPJ;

delete from TESTPJ;